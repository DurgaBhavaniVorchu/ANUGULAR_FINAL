import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms'
import { AppComponent } from './app.component';
import { AddalbumComponent } from './addalbum/addalbum.component';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { MusicService } from './music.service';
import { AlbumListComponent } from './album-list/album-list.component';

@NgModule({
  declarations: [
    AppComponent,
    AddalbumComponent,
    AlbumListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule, 
     FormsModule,
    HttpClientModule
  ],
  providers: [HttpClient,MusicService],
  bootstrap: [AppComponent]
})
export class AppModule { }
