import { Component, OnInit } from '@angular/core';
import { MusicService, Music } from '../music.service';

@Component({
  selector: 'app-album-list',
  templateUrl: './album-list.component.html',
  styleUrls: ['./album-list.component.css']
})
export class AlbumListComponent implements OnInit {

  service:MusicService;
  deptData:Music[]=[];
  createdFlag=false;

  constructor(service:MusicService) 
  {
    this.service=service;
   }

   deleteData(id:number)
   {
     this.service.delete(id);
     this.deptData=this.service.getData();
     alert("Are you sure You want to delete??");
 this.createdFlag=true;
  }
  ngOnInit() {
  //this.service.fetchData();
  this.deptData=this.service.getData();
  }
}
