import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class MusicService {
  http: HttpClient;
  fetch: boolean = false;
  dept: Music[] = [];

  constructor(http:HttpClient) {
    this.http=http;
   }

   add(e:Music)
   {
     this.dept.push(e);
   }

   getData(): Music[]
    {
    return this.dept;
  }

delete(id:number)
{
  let foundIndex=-1;
  for(let i=0;i<this.dept.length;i++)
  {
    let e=this.dept[i]
    if(e.albumid==id)
    {
      foundIndex=i;
      break;
    }
  }
  this.dept.splice(foundIndex,1);
}

}
export class Music
{
albumid:number;
title:string;
artist:string;
price:number;
constructor(albumid:number,title:string,artist:string,price:number)
{
this.albumid=albumid;
this.title=title;
this.artist=artist;
this.price=price;
}
}