import { Component, OnInit } from '@angular/core';
import { Music, MusicService } from '../music.service';

@Component({
  selector: 'app-addalbum',
  templateUrl: './addalbum.component.html',
  styleUrls: ['./addalbum.component.css']
})
export class AddalbumComponent implements OnInit {
  createEmployee:Music
  service:MusicService
  constructor(service:MusicService) 
  {
    this.service=service;
   }

 
addData(data:any)
{
  this.createEmployee=new Music(data.albumid,data.title,data.artist,data.price)
  this.service.add(this.createEmployee);
}
ngOnInit() {
}
}
