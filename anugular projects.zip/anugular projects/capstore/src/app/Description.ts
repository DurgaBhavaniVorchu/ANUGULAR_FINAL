export interface Description{
    descId:number;
    label:String;
    value:String;
}