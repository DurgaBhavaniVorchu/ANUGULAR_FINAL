import { Description } from './Description';

export interface Product{
    productId:number;
    productName:String;
    categoryId:number;
    price:number;
    productDesc:Description;
}