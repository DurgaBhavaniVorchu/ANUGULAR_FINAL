import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Categories } from './Categories';
import { Merchant } from './Merchant';
import { Observable } from 'rxjs';



@Injectable({
  providedIn: 'root'
})
export class AnalysisService {
  category:Categories[];
  merchants:Merchant[];
  constructor(private http:HttpClient) {
    // this.populateCategories().subscribe(data=>this.category=data, error=>console.log(error))
    //  this.populateMerchants().subscribe(data=>{
    //    this.merchants=data;
    //     error=>console.log(error);})
  }
   
  populateCategories():Observable<Categories[]>{
    return this.http.get<Categories[]>("http://localhost:6500/api/v1/categories");
  }
  populateMerchants():Observable<Merchant[]>{
    return this.http.get<Merchant[]>("http://localhost:6500/api/v1/merchant");
  }
  getCategories():Categories[] {
    return this.category;
  }
  getMerchants():Merchant[] {
    return this.merchants;
  }
}

