import { Component, OnInit } from '@angular/core';
import { AnalysisService } from '../analysis.service';
import { Categories } from '../Categories';

@Component({
  selector: 'app-analysis',
  templateUrl: './analysis.component.html',
  styleUrls: ['./analysis.component.css']
})
export class AnalysisComponent implements OnInit {

  category:Categories[];

  constructor(private analysisService:AnalysisService) { }

  ngOnInit() {
    this.analysisService.populateCategories().subscribe(data => {
      
      this.category=data;
    })
}


}
  

