

export interface Merchant{
    merchantId: number;
    firstName: String;
    lastName: String;
    email:String;
    storeName:String;
    phone:String;
    password:String;
    revenue:number;
    
}