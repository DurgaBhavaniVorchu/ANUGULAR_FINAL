import { Component, OnInit } from '@angular/core';
import { AnalysisService } from '../analysis.service';
import { Merchant } from '../Merchant';

@Component({
  selector: 'app-merchant',
  templateUrl: './merchant.component.html',
  styleUrls: ['./merchant.component.css']
})
export class MerchantComponent implements OnInit {
  merchants: Merchant[]
  constructor(private analysisService: AnalysisService) { }

  ngOnInit() {
    this.analysisService.populateMerchants().subscribe(data => {
      // console.log(data);
      this.merchants=data;
    })
    // this.merchants = this.analysisService.getMerchants();
  }

}
