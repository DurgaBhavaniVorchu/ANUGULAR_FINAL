export interface Categories{
    code:string;
    name:string;
}