export interface Employee{
    categoryId:number;
    categoryName:string;
}