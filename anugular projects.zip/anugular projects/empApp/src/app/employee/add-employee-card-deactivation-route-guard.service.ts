import { Injectable } from '@angular/core';
import {  AddEmployeeComponent } from './add-employee.component';
import { CanDeactivate } from '@angular/router';
  

@Injectable({
  providedIn: 'root'
})
export class AddEmployeeCardDeactivationRouteGuardService implements CanDeactivate<AddEmployeeComponent> {

  canDeactivate(component:AddEmployeeComponent): boolean{
    if(component.createEmployeeForm.dirty){
      return confirm("Are you sure you want to discard the data(y/n)");
    }
    return true;
  }
  constructor() { }
}
