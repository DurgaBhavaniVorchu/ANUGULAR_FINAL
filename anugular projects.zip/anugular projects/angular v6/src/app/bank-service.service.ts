import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Customer } from './EntityClasses/Customer';
import { Transaction } from './EntityClasses/Transaction';

@Injectable({
  providedIn: 'root'
})
export class BankServiceService {
  
  http:HttpClient;
  fetchCust:boolean=false;
  fetchTrans:boolean=false;
CustomerArray:Customer[]=[];
TransactionArray:Transaction[]=[];
ShowBal:Customer;
  constructor(http:HttpClient) {
    this.http=http;
   }
   fetchCustomer(){
     this.http.get('./assets/Customer.json').subscribe(
customer=>{
  if(!this.fetchCust){
    this.convertCustomer(customer);
    this.fetchCust=true;
  }
}
     )
   }
   getCustomer(): Customer[] {
  return this.CustomerArray;
  }
  convertCustomer(customer: any) {
   for(let cust of customer){
     let bankCustomer=new Customer(cust.AccNo,cust.Name,cust.PhoneNo,cust.AadharNo,cust.Balance,cust.Pin);
     this.CustomerArray.push(bankCustomer);
   
   }

  }
  CreateAccount(customer:Customer){
    this.CustomerArray.push(customer);
    var myJSON = JSON.stringify(this.CustomerArray);
    alert("your AccountNumber is:"+customer.AccNo);

  }
  ShowBalance(custu:any):Customer{
   for(let i=0;i<this.CustomerArray.length;i++){
     let Custom=this.CustomerArray[i];
    if(Custom.AccNo==custu.AccNo){
      if(Custom.Pin==custu.Pin){
        this.ShowBal=Custom;
        return this.ShowBal;
      }
    }
    }
  }
  Deposit(cust:any){
    for(let i=0;i<this.CustomerArray.length;i++){
      let Custom=this.CustomerArray[i];
     if(Custom.AccNo==cust.AccNo){
       if(Custom.Pin==cust.Pin){
         Custom.Balance=Custom.Balance+cust.Balance;
         alert("deposited Successfully!! current Balance is:"+Custom.Balance);

  }
}
}
  }
  Withdraw(cust:any){
    for(let i=0;i<this.CustomerArray.length;i++){
      let Custom=this.CustomerArray[i];
     if(Custom.AccNo==cust.AccNo){
       if(Custom.Pin==cust.Pin){
         Custom.Balance=Custom.Balance-cust.Balance;
         alert("Withdrawed Successfully!! current Balance is:"+Custom.Balance);

  }
}
}
  }
  FundTransfer(transfer:any){
for(let i=0;i<this.CustomerArray.length;i++){
  let SourceCust=this.CustomerArray[i];
  if(SourceCust.AccNo==transfer.sourceAccNo){
if(SourceCust.Pin==transfer.Pin){
  if(SourceCust.Balance>transfer.Amount){
    for(let j=0;j<this.CustomerArray.length;j++){
      let DestiCust=this.CustomerArray[j];
      if(DestiCust.AccNo==transfer.destiAccNo){
        SourceCust.Balance=SourceCust.Balance-transfer.Amount;
        DestiCust.Balance=DestiCust.Balance+transfer.Amount;
        alert("transfered Successfully!!"+"\n"+" Source Current Balance:"+SourceCust.Balance+"\n"+"Destination Current Balance:"+DestiCust.Balance);
      }
    }
  }
}
  }
}
  }
  fetchTransaction(){
    this.http.get('./assets/Transaction.json').subscribe(
transaction=>{
 if(!this.fetchTrans){
   this.convertTransaction(transaction);
   this.fetchTrans=true;
 }
}
    )
  }
  getTransaction(): Transaction[] {
 return this.TransactionArray;
 }
 convertTransaction(transaction: any) {
  for(let trans of transaction){
    let transObj=new Transaction(transaction.TransactionId,transaction.TransactionType,transaction.AccountNumber,transaction.Amount);
    this.TransactionArray.push(transObj);
  
  }

 }
 addTransaction(transaction:Transaction){
  this.TransactionArray.push(transaction);
  var myJSON1 = JSON.stringify(this.TransactionArray);
 }
 printTransaction(trans:any):Transaction[]{
   let printTransactionArray:Transaction[]=[];
   for(let i=0;i<this.CustomerArray.length;i++){
     let customer=this.CustomerArray[i];
     if(customer.AccNo==trans.AccNo){
       if(customer.Pin==trans.Pin){
         for(let j=0;j<this.TransactionArray.length;j++){
           let transaction=this.TransactionArray[j];
           if(transaction.AccountNumber==trans.AccNo){
             printTransactionArray.push(transaction);
            
           }
         }
         return printTransactionArray;
       }
     }
   }
        
        
 }
  
}
