import { Component, OnInit } from '@angular/core';
import { BankService } from '../bank.service';
import { Transaction } from '../transaction';

@Component({
  selector: 'app-transaction',
  templateUrl: './transaction.component.html',
  styleUrls: ['./transaction.component.css']
})
export class TransactionComponent implements OnInit {

  bankService: BankService;
  transaction: Transaction[] = [];
  showTransaction: boolean = true;

  constructor(bankService: BankService) {
    this.bankService = bankService;
  }


  showTrans() {
    this.showTransaction = !this.showTransaction;
  }

  printTransaction(data: any) {
    this.transaction = this.bankService.printTransaction(data);
  }

  ngOnInit() {
  }

}
