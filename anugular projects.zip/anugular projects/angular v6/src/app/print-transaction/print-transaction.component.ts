import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Transaction } from '../EntityClasses/Transaction';

@Component({
  selector: 'app-print-transaction',
  templateUrl: './print-transaction.component.html',
  styleUrls: ['./print-transaction.component.css']
})
export class PrintTransactionComponent implements OnInit {
bankService:BankServiceService;
transBoo:boolean=true;
transactionArray:Transaction[]=[];
  constructor(bankService:BankServiceService) {
    this.bankService=bankService;
   }

  ngOnInit() {
  }
  printTransaction(trans:any){
    this.transactionArray=this.bankService.printTransaction(trans);
  
    }
    print(){
      this.transBoo=!this.transBoo;
    }

}
