import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Customer } from '../EntityClasses/Customer';
import { Transaction } from '../EntityClasses/Transaction';

@Component({
  selector: 'app-fund-transfer',
  templateUrl: './fund-transfer.component.html',
  styleUrls: ['./fund-transfer.component.css']
})
export class FundTransferComponent implements OnInit {
  bankService:BankServiceService;
  customers: Customer[];
  transactions:Transaction[];
  constructor(bankService:BankServiceService) {
    this.bankService=bankService;
   }

 
 FundTransfer(transfer:any){
    this.bankService.FundTransfer(transfer);
    let transID=Math.floor(Math.random()*10)+100;
    let transID1=Math.floor(Math.random()*10)+100;
    let transObj=new Transaction(transID,"transfered money",transfer.sourceAccNo,transfer.Amount);
    let transObj1=new Transaction(transID1,"received money",transfer.destiAccNo,transfer.Amount);
    this.bankService.addTransaction(transObj1);
    this.bankService.addTransaction(transObj);
    
  }
  ngOnInit() {
    this.bankService.fetchCustomer();
    this.customers=this.bankService.getCustomer();
    this.bankService.fetchTransaction();
    this.transactions=this.bankService.getTransaction();
  }

}
