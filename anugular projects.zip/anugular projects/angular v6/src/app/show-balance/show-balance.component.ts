import { Component, OnInit } from '@angular/core';
import { BankServiceService } from '../bank-service.service';
import { Customer } from '../EntityClasses/Customer';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
banKService:BankServiceService;
CustomerBal:Customer;
customers:Customer[]=[];
ShowBal:Boolean=true;
  constructor(banKService:BankServiceService) {
this.banKService=banKService;

   }
   Name:String;
Balance:number;
  ShowBalance(cust:any){
    this.CustomerBal=this.banKService.ShowBalance(cust);
    this.Name=this.CustomerBal.Name;
    this.Balance=this.CustomerBal.Balance;

  }
  Show(){
    this.ShowBal=!this.ShowBal;
   
  }
  ngOnInit() {
    this.banKService.fetchCustomer();
this.customers=this.banKService.getCustomer();
  }
}
