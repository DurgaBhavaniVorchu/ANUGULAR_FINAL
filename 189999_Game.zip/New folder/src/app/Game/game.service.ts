import { Injectable } from '@angular/core';
import { Games } from './games';
import { HttpClient } from '@angular/common/http';
import { Observable } from '../../../node_modules/rxjs';

@Injectable({
  providedIn: 'root'
})
export class GameService {

  play: Games[];

  cardBalance: number = 600;

  constructor(private http: HttpClient) {
      this.PopGames().subscribe( data => this.play = data, error => console.log(error) );    
   }

   PopGames(): Observable<Games[]> {
    return this.http.get<Games[]>("../../assets/GameList.json");
  }

  getGames(): Games[] {
    return this.play;
  }

  getCardBalance(rate: number): number {
      this.cardBalance = this.cardBalance-rate;
      return this.cardBalance;
  }
}
