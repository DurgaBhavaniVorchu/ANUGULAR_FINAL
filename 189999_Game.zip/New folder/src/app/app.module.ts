import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { PlayComponent } from './Game/Play/play.component';
import { SuccessComponent } from './Game/Success/success.component';
import { DummyComponent } from './Dummy/dummy.component';
import { HttpClientModule } from '@angular/common/http';
import { GameService } from './Game/game.service';

@NgModule({
  declarations: [
    AppComponent,
    PlayComponent,
    SuccessComponent,
    DummyComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [GameService],
  bootstrap: [AppComponent]
})
export class AppModule { }
